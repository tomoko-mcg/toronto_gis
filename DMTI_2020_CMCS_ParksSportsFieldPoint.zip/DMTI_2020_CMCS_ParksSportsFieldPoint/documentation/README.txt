DMTI Spatial Release Notes�
Product Name: CanMap Postal CodeOM* Suite (PCS)�
Version: 2020.3
Date: September 15, 2020
Canada Post Valid Mailing Period: 08/14/2020 to 09/17/2020
